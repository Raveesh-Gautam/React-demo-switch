import './App.css';
import './asssets/style.css'
import SwitchButton from './components/Switch';
function App() {
  return (
    <div className="parentDiv">
        <SwitchButton />
    </div>
  );
}

export default App;
